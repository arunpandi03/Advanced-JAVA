package jd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseConnection {
	public static void main(String args[]) {
		try{  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
			Connection con=DriverManager.getConnection("jdbc:sqlserver://192.168.168.12:1433;databaseName=New_joinee_2022;encrypt=true;trustServerCertificate=true;","NewJoinee2022","P@ssw0rd");
			Statement stmt=con.createStatement(); 
			String myQuery="select * from ARUN_MENU";
		//	stmt.executeUpdate("INSERT INTO ARUN_MENU " + "VALUES (19, 'kal dosa',30)");
		//	stmt.executeUpdate("DELETE FROM ARUN_MENU WHERE  menu_id =19");
			ResultSet rs=stmt.executeQuery(myQuery);
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
			con.close();
		}
		catch(Throwable e){
			//System.out.println(e);
			e.printStackTrace();
		}
	
	}
}