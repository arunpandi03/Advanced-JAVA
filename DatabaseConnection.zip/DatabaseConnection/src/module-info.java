/**
 * 
 */
/**
 * @author User - 2
 *
 */
module DatabaseConnection {
	requires java.sql;
}