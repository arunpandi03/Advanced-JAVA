package as;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerialization  {

	   public static void main(String [] args) {
	      EmpDetails e = new EmpDetails();
	      try {
	         FileInputStream fileIn = new FileInputStream("//C:\\Users\\User\\Downloads\\ranjith.ser");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         in.readObject();
	         in.close();
	         fileIn.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	         return;
	      } catch (ClassNotFoundException c) {
	         System.out.println("Employee class not found");
	         c.printStackTrace();
	         return;
	      }
	      
	      System.out.println("....after Deserialized...");
	      System.out.println("Name: " +e.name);
	      System.out.println("Address: " + e.address);
	      System.out.println("Number: " + e.number);
	   }
	}
