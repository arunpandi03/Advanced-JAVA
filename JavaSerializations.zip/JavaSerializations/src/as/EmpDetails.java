package as;
public class EmpDetails implements java.io.Serializable {
	   public String name;
	   public String address;
	   public int number;
	   
	   public void mailCheck() {
	      System.out.println("send the mail to given emplayee:");
	      
	      System.out.println("Name: " +name);
	      System.out.println("Address: " + address);
	      System.out.println("Number: " + number);
	   }
	   }
