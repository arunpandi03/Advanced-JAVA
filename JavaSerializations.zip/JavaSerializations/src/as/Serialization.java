package as;
import java.io.*;
public class Serialization{

   public static void main(String [] args) {
      EmpDetails e = new EmpDetails ();
      e.name = "Arun";
      e.address = "AnnaNagar ";
      e.number = 987654;
      try {
         FileOutputStream fileOut = new FileOutputStream("C:\\Users\\User\\Downloads\\Ranjith.ser");
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(e);  
         out.close();
         fileOut.close();
     e.mailCheck();
      } catch (IOException i) {
         i.printStackTrace();
      }
   }
}