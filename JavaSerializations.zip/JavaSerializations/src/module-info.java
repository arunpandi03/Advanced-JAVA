/**
 * 
 */
/**
 * @author User - 2
 *
 */
module JavaSerializations {
}